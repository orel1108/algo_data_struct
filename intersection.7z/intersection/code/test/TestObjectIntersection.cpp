#include "TestObjectIntersection.hpp"

#include "Object.hpp"
#include "Utils.hpp"

#include <cassert>

void test_bunny_bunny()
{
    Object o1, o2;
    o1.read("Objects/bunny.obj");
    o2.read("Objects/bunny.obj");
    
    intersects(o1, o2);
}

void test_bunny_gear()
{
    Object o1, o2;
    o1.read("Objects/bunny.obj");
    o2.read("Objects/gear.obj");

    intersects(o1, o2);
}

void test_bunny_lamp()
{
    Object o1, o2;
    o1.read("Objects/bunny.obj");
    o2.read("Objects/lamp.obj");

    intersects(o1, o2);
}

void test_bunny_table()
{
    Object o1, o2;
    o1.read("Objects/bunny.obj");
    o2.read("Objects/table.obj");

    intersects(o1, o2);
}

void test_gear_gear()
{
    Object o1, o2;
    o1.read("Objects/gear.obj");
    o2.read("Objects/gear.obj");

    intersects(o1, o2);
}

void test_gear_lamp()
{
    Object o1, o2;
    o1.read("Objects/gear.obj");
    o2.read("Objects/lamp.obj");

    intersects(o1, o2);
}

void test_gear_table()
{
    Object o1, o2;
    o1.read("Objects/gear.obj");
    o2.read("Objects/table.obj");

    intersects(o1, o2);
}

void test_lamp_lamp()
{
    Object o1, o2;
    o1.read("Objects/lamp.obj");
    o2.read("Objects/lamp.obj");

    intersects(o1, o2);
}

void test_lamp_table()
{
    Object o1, o2;
    o1.read("Objects/lamp.obj");
    o2.read("Objects/table.obj");

    intersects(o1, o2);
}

void test_table_table()
{
    Object o1, o2;
    o1.read("Objects/table.obj");
    o2.read("Objects/table.obj");

    intersects(o1, o2);
}

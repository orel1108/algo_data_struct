#include "TestTriangleTriangleIntersection.hpp"

#include "TriangleParticle.hpp"
#include "TriangleIntersectionUtil.hpp"
#include "Utils.hpp"

#include <cassert>

void test_coplanar_interset()
{
    
    TriangleParticle t1{ 1.0, 1.0, 0.0, 3.0, 1.0, 0.0, 1.0, 3.0, 0.0 };
    TriangleParticle t2{ 1.0, 1.0, 0.0, 3.0, 1.0, 0.0, 3.0, 3.0, 0.0 };

    assert(intersects_triangle_triangle(t1, t2));
    assert(intersects(t1, t2));
}

void test_coplanar_no_interset()
{

    TriangleParticle t1{ 1.0, 1.0, 0.0, 3.0, 1.0, 0.0, 1.0, 3.0, 0.0 };
    TriangleParticle t2{ 10.0, 1.0, 0.0, 13.0, 1.0, 0.0, 13.0, 3.0, 0.0 };

    assert(!intersects_triangle_triangle(t1, t2));
    assert(!intersects(t1, t2));
}

void test_non_coplanar_no_interset()
{
    TriangleParticle t1{ 1.0, 1.0, 0.0, 3.0, 1.0, 0.0, 1.0, 3.0, 0.0 };
    TriangleParticle t2{ 5.0, 1.0, 1.0, 7.0, 1.0, 1.0, 5.0, 3.0, 1.0 };

    assert(!intersects_triangle_triangle(t1, t2));
    assert(!intersects(t1, t2));
}

void test_non_coplanar_interset()
{
    TriangleParticle t1{ 1.0, 1.0, 0.0, 3.0, 1.0, 0.0, 1.0, 3.0, 0.0 };
    TriangleParticle t2{ 5.0, 2.0, 0.0, 0.0, 2.0, 5.0, 0.0, 2.0, -5.0 };

    assert(intersects_triangle_triangle(t1, t2));
    assert(intersects(t1, t2));
}

void test_parallel_no_intersect()
{
    TriangleParticle t1{ 1.0, 1.0, 0.0, 3.0, 1.0, 0.0, 1.0, 3.0, 0.0 };
    TriangleParticle t2{ 1.0, 1.0, 1.0, 3.0, 1.0, 1.0, 1.0, 3.0, 1.0 };

    assert(!intersects_triangle_triangle(t1, t2));
    assert(!intersects(t1, t2));
}
#pragma once

void test_bunny_bunny();

void test_bunny_gear();

void test_bunny_lamp();

void test_bunny_table();

void test_gear_gear();

void test_gear_lamp();

void test_gear_table();

void test_lamp_lamp();

void test_lamp_table();

void test_table_table();

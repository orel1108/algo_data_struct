#pragma once

void test_coplanar_interset();

void test_coplanar_no_interset();

void test_non_coplanar_no_interset();

void test_non_coplanar_interset();

void test_parallel_no_intersect();


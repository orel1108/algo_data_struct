#pragma once

class TriangleParticle; /**< Forward declaration of triangle particle. */

/**
 * @brief Checks if two triangle intersect.
 * @param[in] i_triangle1 First triangle.
 * @param[in] i_triangle2 Second triangle.
 * @return true if triangles intersect and false otherwise.
 */
bool intersects_triangle_triangle(const TriangleParticle & i_triangle1, const TriangleParticle & i_triangle2);

#include "TriangleParticle.hpp"
#include "TriangleIntersectionUtil.hpp"

/**
* @brief Visits triangle particle.
* @param[in] i_triangle Input triangle.
*/
void TriangleIntersecter::visit(const TriangleParticle & i_triangle)
{
    m_result = intersects_triangle_triangle(m_left, i_triangle);
}

/**
* @brief Method accepts visitor.
* @param[in] i_v Visitor.
*/
void TriangleParticle::accept(Visitor & i_visitor) const
{ 
    i_visitor.visit(*this);
}

/**
* @brief Returns intersecter type.
*/
TriangleIntersecter * TriangleParticle::intersecter() const
{ 
    return new TriangleIntersecter(*this);
}

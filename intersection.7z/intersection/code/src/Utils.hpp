#pragma once

class BaseParticle;  /**< Forward declarations. */
class Object;

/**
 * @brief Checks if two particles of object intersect.
 * @param[in] i_left Left particle.
 * @param[in] i_right Right particle.
 * @return true if particles intersect and false otherwise.
 */
bool intersects(const BaseParticle & i_left, const BaseParticle & i_right);

/**
* @brief Checks if two objects intersect.
* @param[in] i_left Left object.
* @param[in] i_right Right object.
* @return true if objects intersect and false otherwise.
*/
bool intersects(const Object & i_left, const Object & i_right);

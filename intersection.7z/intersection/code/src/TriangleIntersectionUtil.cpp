#include <cmath>
#include <iostream>
#include <tuple>

#include "TriangleParticle.hpp"
#include "types.hpp"

// anonymous namespace (instead of static functions)
namespace
{
    /**
     * @brief Calculates cross-product of two 3D vectors.
     * @param[in] i_u First vector.
     * @param[in] i_v Second vector.
     * @return Resulting vector.
     */
    Vector3D cross_product(const Vector3D & i_u, const Vector3D & i_v)
    {
        Vector3D res;
        // calculate determinant of
        //  i    j    k
        // u[0] u[1] u[2]
        // v[0] v[1] v[2] 
        res.coord[0] = i_u.coord[1] * i_v.coord[2] - i_u.coord[2] * i_v.coord[1];
        res.coord[1] = i_u.coord[2] * i_v.coord[0] - i_u.coord[0] * i_v.coord[2];
        res.coord[2] = i_u.coord[0] * i_v.coord[1] - i_u.coord[1] * i_v.coord[0];
        return res;
    }

    /**
    * @brief Calculates dot-product of two 3D vectors.
    * @param[in] i_u First vector.
    * @param[in] i_v Second vector.
    * @return Resulting value.
    */
    double dot_product(const Vector3D & i_u, const Vector3D & i_v)
    {
        return i_u.coord[0] * i_v.coord[0] + i_u.coord[1] * i_v.coord[1] + i_u.coord[2] * i_v.coord[2];
    }

    /**
     * @brief Calculates norm of 3D vector.
     * @param[in] i_v Input vector.
     * @return Norm of vector.
     */
    double norm(const Vector3D & i_v)
    {
        return sqrt(dot_product(i_v, i_v));
    }

    /**
     * @brief Calculates difference of two 3D vectors.
     * @param[in] i_v First vector.
     * @param[in] i_u Second vector.
     * @return First - Second.
     */
    Vector3D operator-(const Vector3D & i_v, const Vector3D & i_u)
    {
        Vector3D res;
        res.coord[0] = i_v.coord[0] - i_u.coord[0];
        res.coord[1] = i_v.coord[1] - i_u.coord[1];
        res.coord[2] = i_v.coord[2] - i_u.coord[2];

        return res;
    }

    bool edge_to_edges(double i_ax, double i_ay, double i_bx, double i_by, double i_cx, double i_cy)
    {
        double d1, d2, d3;
        d1 = i_ay * i_bx - i_ax * i_by;
        d2 = i_by * i_cx - i_bx * i_cy;
        if ((d1 > 0 && d2 >= 0 && d2 <= d1) || (d1 < 0 && d2 <= 0 && d2 >= d1))
        {
            d3 = i_ax * i_cy - i_ay * i_cx;
            if (d1 > 0)
            {
                if (d3 >= 0 && d3 <= d1)
                {
                    return true;
                }
            }
            else
            {
                if (d3 <= 0 && d3 >= d1)
                {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * @brief Checks if two coplanar 3D vectors intersect.
     * @param[in] i_n Normal to triangles plane.
     * @param[in] i_triangle1 First triangle.
     * @param[in] i_triangle2 Second triangle.
     * @return true if triangles intersect and false otherwise.
     */
    bool coplanar_intersection(const Vector3D & i_n, const TriangleParticle & i_triangle1, const TriangleParticle & i_triangle2)
    {
        double Ax, Ay, Bx, By, Cx, Cy;
        double d0, d1, d2;

        // modulus of normal vector coordinates
        double x = std::fabs(i_n.coord[0]), y = std::fabs(i_n.coord[1]), z = std::fabs(i_n.coord[2]);

        Point3D vert_a, vert_b, vert_c;
        Vector3D veca1, vecb1, vecc1, veca2, vecb2, vecc2;

        // get vertices of first triangle.
        std::tie(vert_a, vert_b, vert_c) = i_triangle1.get_vertices();
        // convert to 3D vector type
        veca1 = Vector3D{ vert_a.x, vert_a.y, vert_a.z };
        vecb1 = Vector3D{ vert_b.x, vert_b.y, vert_b.z };
        vecc1 = Vector3D{ vert_c.x, vert_c.y, vert_c.z };

        // get vertices of first triangle.
        std::tie(vert_a, vert_b, vert_c) = i_triangle2.get_vertices();
        // convert to 3D vector type
        veca2 = Vector3D{ vert_a.x, vert_a.y, vert_a.z };
        vecb2 = Vector3D{ vert_b.x, vert_b.y, vert_b.z };
        vecc2 = Vector3D{ vert_c.x, vert_c.y, vert_c.z };

        std::size_t idx0, idx1;
        // find two smallest coordinates
        if (x > y)
        {
            if (x > z)
            {
                idx0 = 1;
                idx1 = 2;
            }
            else
            {
                idx0 = 0;
                idx1 = 1;
            }
        }
        else
        {
            if (z > y)
            {
                idx0 = 0;
                idx1 = 1;
            }
            else
            {
                idx0 = 0;
                idx1 = 2;
            }
        }

        double A1x = veca1.coord[idx0], A1y = veca1.coord[idx1];
        double A2x = veca2.coord[idx0], A2y = veca2.coord[idx1];

        double B1x = vecb1.coord[idx0], B1y = vecb1.coord[idx1];
        double B2x = vecb2.coord[idx0], B2y = vecb2.coord[idx1];

        double C1x = vecc1.coord[idx0], C1y = vecc1.coord[idx1];
        double C2x = vecc2.coord[idx0], C2y = vecc2.coord[idx1];

        ///////////////////////////////////////

        // edge: A1 -> B1
        Ax = B1x - A1x;
        Ay = B1y - A1y;
        // edge: B2 -> A2
        Bx = A2x - B2x;
        By = A2y - B2y;
        // edge: A2 -> A1
        Cx = A1x - A2x;
        Cy = A1y - A2y;
        // test B2 -> A2 -> A1 -> B1
        if (edge_to_edges(Ax, Ay, Bx, By, Cx, Cy))
        {
            return true;
        }

        // edge: C2 -> B2
        Bx = B2x - C2x;
        By = B2y - C2y;
        // edge: B2 -> A1
        Cx = A1x - B2x;
        Cy = A1y - B2y;
        // test C2 -> B2 -> A1 -> B1
        if (edge_to_edges(Ax, Ay, Bx, By, Cx, Cy))
        {
            return true;
        }
        
        // edge: A2 -> C2
        Bx = C2x - A2x;
        By = C2y - A2y;
        // edge: C2 -> A1
        Cx = A1x - C2x;
        Cy = A1y - C2y;
        // test A2 -> C2 -> A1 -> B1
        if (edge_to_edges(Ax, Ay, Bx, By, Cx, Cy))
        {
            return true;
        }

        ///////////////////////////////////////

        ///////////////////////////////////////

        // edge: B1 -> C1
        Ax = C1x - B1x;
        Ay = C1y - B1y;
        // edge: B2 -> A2
        Bx = A2x - B2x;
        By = A2y - B2y;
        // edge: A2 -> B1
        Cx = B1x - A2x;
        Cy = B1y - A2y;
        // test B2 -> A2 -> B1 -> C1
        if (edge_to_edges(Ax, Ay, Bx, By, Cx, Cy))
        {
            return true;
        }

        // edge: C2 -> B2
        Bx = B2x - C2x;
        By = B2y - C2y;
        // edge: B2 -> B1
        Cx = B1x - B2x;
        Cy = B1y - B2y;
        // test C2 -> B2 -> B1 -> C1
        if (edge_to_edges(Ax, Ay, Bx, By, Cx, Cy))
        {
            return true;
        }

        // edge: A2 -> C2
        Bx = C2x - A2x;
        By = C2y - A2y;
        // edge: C2 -> B1
        Cx = B1x - C2x;
        Cy = B1y - C2y;
        // test A2 -> C2 -> B1 -> C1
        if (edge_to_edges(Ax, Ay, Bx, By, Cx, Cy))
        {
            return true;
        }

        ///////////////////////////////////////

        ///////////////////////////////////////

        // edge: C1 -> A1
        Ax = A1x - C1x;
        Ay = A1y - C1y;
        // edge: B2 -> A2
        Bx = A2x - B2x;
        By = A2y - B2y;
        // edge: A2 -> C1
        Cx = C1x - A2x;
        Cy = C1y - A2y;
        // test B2 -> A2 -> C1 -> A1
        if (edge_to_edges(Ax, Ay, Bx, By, Cx, Cy))
        {
            return true;
        }

        // edge: C2 -> B2
        Bx = B2x - C2x;
        By = B2y - C2y;
        // edge: B2 -> C1
        Cx = C1x - B2x;
        Cy = C1y - B2y;
        // test C2 -> B2 -> C1 -> A1
        if (edge_to_edges(Ax, Ay, Bx, By, Cx, Cy))
        {
            return true;
        }

        // edge: A2 -> C2
        Bx = C2x - A2x;
        By = C2y - A2y;
        // edge: C2 -> C1
        Cx = C1x - C2x;
        Cy = C1y - C2y;
        // test A2 -> C2 -> C1 -> A1
        if (edge_to_edges(Ax, Ay, Bx, By, Cx, Cy))
        {
            return true;
        }

        ///////////////////////////////////////

        // check if point inside triangle

        d0 = (B2y - A2y) * (A1x - A2x) - (B2x - A2x) * (A1y - A2y);
        d1 = (C2y - B2y) * (A1x - B2x) - (C2x - B2x) * (A1y - B2y);
        d2 = (A2y - C2y) * (A1x - C2x) - (A2x - C2x) * (A1y - C2y);
        if (d0 * d1 > 0.0)
        { 
            if (d0 * d2 > 0.0)
            {
                return true;
            }
        }

        d0 = (B1y - A1y) * (A2x - A1x) - (B1x - A1x) * (A2y - A1y);
        d1 = (C1y - B1y) * (A2x - B1x) - (C1x - B1x) * (A2y - B1y);
        d2 = (A1y - C1y) * (A2x - C1x) - (A1x - C1x) * (A2y - C1y);
        if (d0 * d1 > 0.0)
        { 
            if (d0 * d2 > 0.0)
            {
                return true;
            }
        }

        return false;
    }

    /**
     * @brief Implements calculation of intersection interval parameters 
     * intersection of triangle with traingles planes intersection line.
     * @param[in] i_p0 Projection of first vertex.
     * @param[in] i_p1 Projection of second vertex.
     * @param[in] i_p2 Projection of third vertex.
     * @param[in] i_d0 Distance from first vertex to second plane.
     * @param[in] i_d1 Distance from second vertex to second plane.
     * @param[in] i_d2 Distance from third vertex to second plane.
     * @return Tuple of coefficients of intersection.
     */
    std::tuple<double, double, double, double, double> compute_intervals(double i_p0, double i_p1, double i_p2, double i_d0, double i_d1, double i_d2)
    {
        double a, b, c, x, y;

        if (i_d0 * i_d1 > 0.0) // then d0 * d2 <= 0, A and B lies on same side
        {
            a = i_p2, b = (i_p0 - i_p2) * i_d2, c = (i_p1 - i_p2) * i_d2, x = i_d2 - i_d0, y = i_d2 - i_d1;
        }
        else if (i_d0 * i_d2 > 0.0) // then d0 * d1 <= 0, A and C lies on same side
        {
            a = i_p1, b = (i_p0 - i_p1) * i_d1, c = (i_p2 - i_p1) * i_d1, x = i_d1 - i_d0, y = i_d1 - i_d2;
        }
        else if (i_d1 * i_d2 > 0.0 || i_d0 != 0.0) // then d0 * d1 <= 0.0 or that d0 != 0.0, B and C on the same side or A not on plane and B and C on plane
        {
            a = i_p0, b = (i_p1 - i_p0) * i_d0, c = (i_p2 - i_p0) * i_d0, x = i_d0 - i_d1, y = i_d0 - i_d2;
        }
        else if (i_d1 != 0.0) // B not on plane, A and C on lane
        {
            a = i_p1, b = (i_p0 - i_p1) * i_d1, c = (i_p2 - i_p1) * i_d1, x = i_d1 - i_d0, y = i_d1 - i_d2;
        }
        else if (i_d2 != 0.0) // C not on plane, A and B on lane
        {
            a = i_p2, b = (i_p0 - i_p2) * i_d2, c = (i_p1 - i_p2) * i_d2, x = i_d2 - i_d0, y = i_d2 - i_d1;
        }

        return std::make_tuple(a, b, c, x, y);
    }
}

/**
 * @brief Check if two triangles intersects.
 * @param[in] i_triangle1 First triangle.
 * @param[in] i_triangle2 Second triangle.
 * @return true if triangles intersect and false otherwise. 
 */
bool intersects_triangle_triangle(const TriangleParticle & i_triangle1, const TriangleParticle & i_triangle2)
{
    Point3D a1, b1, c1, a2, b2, c2;
    Vector3D v1, v2, n, n1, n2;
    Vector3D veca1, vecb1, vecc1, veca2, vecb2, vecc2;
    // distances from vertices of triangles to traingles planes
    double d1a, d1b, d1c, d2a, d2b, d2c;
    // proections
    double p11, p12, p13, p21, p22, p23;
    std::size_t idx;

    // parameters which will characterize intersection 
    // of triangles with planes intersection line
    std::pair<double, double> t, s;

    // convert vertices of triangles to vector type
    std::tie(a1, b1, c1) = i_triangle1.get_vertices();

    veca1 = Vector3D{ a1.x, a1.y, a1.z };
    vecb1 = Vector3D{ b1.x, b1.y, b1.z };
    vecc1 = Vector3D{ c1.x, c1.y, c1.z };

    // convert vertices of triangles to vector type
    std::tie(a2, b2, c2) = i_triangle2.get_vertices();

    veca2 = Vector3D{ a2.x, a2.y, a2.z };
    vecb2 = Vector3D{ b2.x, b2.y, b2.z };
    vecc2 = Vector3D{ c2.x, c2.y, c2.z };

    // compute equation of the plane of the first triangle: n * x + d = 0
    v1 = vecb1 - veca1;
    v2 = vecc1 - veca1;
    // plane normal
    n1 = cross_product(v1, v2);
    // norm of vector
    double norm1 = norm(n1);
    n1.coord[0] /= norm1;
    n1.coord[1] /= norm1;
    n1.coord[2] /= norm1;

    // compute signed distances from vertices of the second triangle to plane
    d1a = dot_product(n1, veca2 - veca1);
    d1b = dot_product(n1, vecb2 - veca1);
    d1c = dot_product(n1, vecc2 - veca1);

    // all distances has the same sign and no one lies on plane
    if (d1a * d1b > 0.0 && d1a * d1c > 0.0)
    {
        return false;
    }

    // triangles are coplanar
    if (d1a == 0.0 && d1b == 0.0 && d1c == 0.0)
    {
        return coplanar_intersection(n1, i_triangle1, i_triangle2);
    }

    // compute equation of the plane of the second triangle: n * x + d = 0
    v1 = vecb2 - veca2;
    v2 = vecc2 - veca2;
    // plane normal
    n2 = cross_product(v1, v2);
    // norm of vector
    double norm2 = norm(n2);
    n2.coord[0] /= norm2;
    n2.coord[1] /= norm2;
    n2.coord[2] /= norm2;
    
    // compute signed distances from vertices of the first triangle to plane
    d2a = dot_product(n2, veca1 - veca2);
    d2b = dot_product(n2, vecb1 - veca2);
    d2c = dot_product(n2, vecc1 - veca2);

    // all distances has the same sign and no one lies on plane
    if (d2a * d2b > 0.0 && d2a * d2c > 0.0)
    {
        return false;
    }

    // triangles are coplanar
    if (d2a == 0.0 && d2b == 0.0 && d2c == 0.0)
    {
        return coplanar_intersection(n1, i_triangle1, i_triangle2);
    }

    // direction of intersection line: L = x + t * n, x - offset
    n = cross_product(n1, n2);

    // find projections to intersection line
    // pr = n * (vertex - x), also intervals can be translated without altering the result and
    // the result of overlap doesn't change if project L onto coordinate axis with which it is most closely aligned.

    // find index of largest component
    idx = n.max_index();

    if (idx == 0)
    {
        p11 = a1.x, p12 = b1.x, p13 = c1.x;
        p21 = a2.x, p22 = b2.x, p23 = c2.x;
    }
    else if (idx == 1)
    {
        p11 = a1.y, p12 = b1.y, p13 = c1.y;
        p21 = a2.y, p22 = b2.y, p23 = c2.y;
    }
    else
    {
        p11 = a1.z, p12 = b1.z, p13 = c1.z;
        p21 = a2.z, p22 = b2.z, p23 = c2.z;
    }

    double a, b, c, x0, x1;
    double d, e, f, y0, y1;

    /*
     t11 = p11 + (p12 - p11) * d1a / (d1a - d1b), t13 = p11 + (p13 - p11) * d1a / (d1a - d1c) | * ( (d1a - d1b) * (d1a - d1c) * (d2a - d2b) * (d2a - d2c) )
     t21 = p21 + (p22 - p21) * d2a / (d2a - d2b), t23 = p21 + (p23 - p21) * d2a / (d2a - d2c) | * ( (d1a - d1b) * (d1a - d1c) * (d2a - d2b) * (d2a - d2c) )

     then
     x0 = (d1a - d1b), x1 = (d1a - d1c), y0 = (d2a - d2b), y1 = (d2a - d2c)
     z = x0 * x1 * y0 * y1
     a = p11, b = (p12 - p11) * d1a, c = (p12 - p13) * d1a
     d = p21, e = (p22 - p21) * d2a, f = (p23 - p21) * d2a
     t11' = a * z + b * x1 * y, t12' = a * z + c * x0 * y
     t21' = a * z + b * x1 * y, t22' = c * x0 * y
    */

    // compute intersection interval between first triangle and planes intersection line
    std::tie(a, b, c, x0, x1) = compute_intervals(p11, p12, p13, d1a, d1b, d1c);
    
    // compute intersection interval between second triangle and planes intersection line
    std::tie(d, e, f, y0, y1) = compute_intervals(p21, p22, p23, d2a, d2b, d2c);
   
    double x = x0 * x1;
    double y = y0 * y1;
    double z = x * y;
    
    // find intersection of the first triangle with planes intersection line
    t.first  = std::fmin(a * z + b * x1 * y, a * z + c * x0 * y);
    t.second = std::fmax(a * z + b * x1 * y, a * z + c * x0 * y);
    
    // find intersection of the second triangle with planes intersection line
    s.first  = std::fmin(d * z + e * x * y1, d * z + f * x * y0);
    s.second = std::fmax(d * z + e * x * y1, d * z + f * x * y0);
    
    // check intersection of scalar intervals
    if (t.second < s.first || s.second < t.first)
    {
        return false;
    }

    return true;
}

#pragma once

class Visitor;      /** Forward declarations of Visitor and Intersecter types. */
class Intersecter;

/**
 * @brief Declaration of base particle type which will form whole object.
 */
class BaseParticle
{
public:
    /**
     * @brief Pure virtual method which will accept any type of visitor.
     * @param[in] i_visitor Visitor object.
     */
    virtual void accept(Visitor & i_visitor) const = 0;

    /**
     * @brief Pure virtual method which will create appropriate intersection visitor.
     * @return Appropriate intersecter.
     */
    virtual Intersecter * intersecter() const = 0;
};

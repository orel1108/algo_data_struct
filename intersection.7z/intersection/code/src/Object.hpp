#pragma once

#include <vector>
#include <string>
#include <memory>

class BaseParticle;

/**
 * @brief Implementation of Object class (consists from list of particles).
 */
class Object
{
public:
    /**
     * @brief Appends new particle of object.
     * @param[in] i_particle Pointer to particle to be added.
     */
    void append(const std::shared_ptr<BaseParticle> & i_particle)
    {
        m_particles.push_back(i_particle);
    }

    /**
     * @brief Read objects particles from file.
     * @param[in] i_filename Name of file where object stored.
     */
    void read(const std::string & i_filename);

    /**
     * @brief Gets list of particles from object.
     * @return List of particles.
     */
    std::vector<std::shared_ptr<BaseParticle>> particles() const
    {
        return m_particles;
    }

private:
    std::vector<std::shared_ptr<BaseParticle>> m_particles; /**< Particles that make up the object. */
};

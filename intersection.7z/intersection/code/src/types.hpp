#pragma once

#include <cstddef>

/**
 * @brief Declaration of 3D point.
 */
struct Point3D
{
    Point3D(double i_x = 0, double i_y = 0, double i_z = 0)
        : x{ i_x }
        , y{ i_y }
        , z{ i_z }
    {}

    double x, y, z; /**< Coordinate of point. */
};

/**
 * @brief Declaration of vector in 3 dimensional space.
 */
struct Vector3D
{
    /**
     * @brief Default constructor.
     */
    Vector3D(double i_x = 0, double i_y = 0, double i_z = 0)
    {
        coord[0] = i_x;
        coord[1] = i_y;
        coord[2] = i_z;
    }

    /**
     * @brief Calculates index of maximal component.
     * @return Index of maximal component.
     */
    std::size_t max_index() const
    {
        std::size_t idx = 0;
        double m = coord[0];

        if (coord[1] > m)
        {
            m = coord[1];
            idx = 1;
        }

        if (coord[2] > m)
        {
            m = coord[2];
            idx = 2;
        }

        return idx;
    }

    double coord[3];  /** Coordinates of vector. */
};


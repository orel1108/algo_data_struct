#pragma once

#include <tuple>

#include "Intersecter.hpp"
#include "BaseParticle.hpp"
#include "types.hpp"

class TriangleParticle;    /** Forward declaration. */

/**
 * @brief Implements TriangleIntersecter class.
 */
class TriangleIntersecter : public Intersecter
{
public:
    /**
     * @brief Explicit constructor.
     * @param[in] i_triangle Input triangle.
     */
    explicit TriangleIntersecter(const TriangleParticle & i_triangle)
        : m_left{ i_triangle }
    {}

    /**
     * @brief Visits triangle particle.
     * @param[in] i_triangle Input triangle.
     */
    virtual void visit(const TriangleParticle & i_triangle);

private:
    const TriangleParticle & m_left;   /**< Left operand of intersection. */
};

/**
 * @brief Definition of triangle particle type.
 */
class TriangleParticle : public BaseParticle
{
public:
    /**
     * @brief Default constructor.
     */
    TriangleParticle(double i_ax = 0, double i_ay = 0, double i_az = 0,
        double i_bx = 0, double i_by = 0, double i_bz = 0,
        double i_cx = 0, double i_cy = 0, double i_cz = 0)
        : m_a{ i_ax, i_ay, i_az }
        , m_b{ i_bx, i_by, i_bz }
        , m_c{ i_cx, i_cy, i_cz }
    {}

    /**
     * @brief Constructor.
     * @param[in] i_a First vertex of triangle.
     * @param[in] i_b Second vertex of triangle.
     * @param[in] i_c Third vertex of triangle.
     */
    TriangleParticle(const Point3D & i_a, const Point3D & i_b, const Point3D & i_c)
        : m_a{ i_a }
        , m_b{ i_b }
        , m_c{ i_c }
    {}

    /**
     * @brief Method accepts visitor.
     * @param[in] i_v Visitor.
     */
    virtual void accept(Visitor & i_v) const;

    /**
     * @brief Returns intersecter type.
     */
    virtual TriangleIntersecter * intersecter() const;

    /**
     * @brief Getters for Triangle vertices.
     */
    Point3D get_a() const { return m_a; }
    Point3D get_b() const { return m_b; }
    Point3D get_c() const { return m_c; }

    /**
     * @brief Get triangle vertices;
     */
    std::tuple<Point3D, Point3D, Point3D> get_vertices() const { return std::make_tuple(m_a, m_b, m_c); }

private:
    Point3D m_a, m_b, m_c;  /**< Points of triangle. */
};

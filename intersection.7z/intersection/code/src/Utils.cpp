#include "Utils.hpp"
#include "Intersecter.hpp"
#include "BaseParticle.hpp"
#include "Object.hpp"

#include <memory>
#include <vector>
#include <atomic>
#include <thread>

/**
* @brief Checks if two particles of object intersect.
* @param[in] i_left Left particle.
* @param[in] i_right Right particle.
* @return true if particles intersect and false otherwise.
*/
bool intersects(const BaseParticle & i_left, const BaseParticle & i_right)
{
    std::shared_ptr<Intersecter> intersecter(i_left.intersecter());
    i_right.accept(*intersecter);
    return intersecter->result();
}

/**
* @brief Checks if two objects intersect.
* @param[in] i_left Left object.
* @param[in] i_right Right object.
* @return true if objects intersect and false otherwise.
*/
bool intersects(const Object & i_left, const Object & i_right)
{
    //std::atomic<bool> res{ false };
    //
    //auto test_intersect = [](const std::shared_ptr<BaseParticle> & i_left, const std::shared_ptr<BaseParticle> & i_right, std::atomic<bool> & io_res)
    //{
    //    bool res = intersects(*i_left.get(), *i_right.get());
    //    io_res = io_res.load() | res;
    //};

    std::vector<std::shared_ptr<BaseParticle>> left = i_left.particles();
    std::vector<std::shared_ptr<BaseParticle>> right = i_right.particles();

    std::vector<std::shared_ptr<BaseParticle>>::const_iterator lit = left.begin(), rit;
    // loop through particles of first object
    for (; lit != left.end(); ++lit)
    {
        rit = right.begin();
        // loop through particles of second object
        for (; rit != right.end(); ++rit)
        {
            //std::thread t(test_intersect, *lit, *rit, std::ref(res));
            // check intersection between particles
            if (intersects(*lit->get(), *rit->get()))
            {
                return true;
            }
            //t.join();
            //if (res)
            //{
            //    return true;
            //}
        }
    }
 
    return false;
}

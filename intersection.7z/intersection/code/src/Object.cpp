#include "Object.hpp"
#include "types.hpp"
#include "TriangleParticle.hpp"

#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <memory>

void Object::read(const std::string & i_filename)
{
    // clear previous data
    m_particles.clear();

    std::ifstream reader(i_filename);
    
    // list of vertices which will form object
    std::vector<Point3D> vertices;

    // read file
    for (std::string line; std::getline(reader, line);)
    {
        std::istringstream parser(line);
        std::string command;

        if (!(parser >> command))
        {
            continue;
        }

        if (command == "v") // read vertex
        {
            Point3D p;
            parser >> p.x;
            parser >> p.y;
            parser >> p.z;

            vertices.push_back(p);
        }
        else if (command == "f") // read face (triangle particle)
        {
            int idx;
            Point3D points[3];
            for (int cnt = 0; cnt < 3; ++cnt)
            {
                parser >> idx;
                points[cnt] = vertices[idx - 1];
            }

            m_particles.push_back(std::make_shared<TriangleParticle>(points[0], points[1], points[3]));
        }
    }
}

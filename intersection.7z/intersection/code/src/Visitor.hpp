#pragma once

class TriangleParticle;  /**< Forward declaration of particle type which will form whole object. */

/**
 * @brief Declaration of Visitor abstract base class.
 */
class Visitor
{
public:
    /**
     * @brief Pure virtual function.
     * @param[in] i_triangle Triangle to be visited.
     */
    virtual void visit(const TriangleParticle & i_triangle) = 0;
};

#pragma once

#include "Visitor.hpp"

/**
 * @brief Implementation of Intersecter class.
 */
class Intersecter : public Visitor
{
public:
    /**
     * @brief Default constructor.
     */
    Intersecter()
        : m_result{ false }
    {}

    /**
     * @brief Gets result of intersection.
     */
    bool result() const { return m_result; }

protected:
    bool m_result; /**< Result of intersection. */
};

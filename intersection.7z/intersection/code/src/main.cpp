#include <iostream>
#include <chrono>

#include "TestTriangleTriangleIntersection.hpp"
#include "TestObjectIntersection.hpp"

int main()
{
    std::cout << "Test" << std::endl;

    std::chrono::time_point<std::chrono::system_clock> start, end;

    start = std::chrono::system_clock::now();

    // test triangle intersections
    test_coplanar_interset();
    test_coplanar_no_interset();
    test_non_coplanar_no_interset();
    test_non_coplanar_interset();
    test_parallel_no_intersect();

    // test object intersections
    test_bunny_bunny();
    test_bunny_gear();
    test_bunny_lamp();
    test_bunny_table();
    test_gear_gear();
    test_gear_lamp();
    test_gear_table();
    test_lamp_lamp();
    test_lamp_table();
    test_table_table();

    end = std::chrono::system_clock::now();

    std::cout << "Elapsed time: " << std::chrono::duration_cast<std::chrono::seconds>(end - start).count() << "sec." << std::endl;

    return 0;
}